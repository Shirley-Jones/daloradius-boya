<?php
class test{
	private $user;
	public $isuser = false;
	private $username;

	public function __construct($username,$password="",$check=false){
		$this->username = $username;
		$password = trim($password);
		if($password == "" && $check == false){
			$info = db('radcheck')->where(array('username'=>$username))->find();
		}else{
			$info = db('radcheck')->where(array('username'=>$username,'value'=>$password))->find();
		}
		if($info){
			$this->isuser = true;
			$this->user = $info;
		}else{
			$this->user = array();
		}
		
	}
	
	public function getllts(){
		if($this->isuser){
			$u = $this->username;
			$Upload_traffic = db('radacct')->where(array('username'=>$u))->field('SUM(acctinputoctets)')->select();//上传流量
			$Download_traffic = db('radacct')->where(array('username'=>$u))->field('SUM(acctoutputoctets)')->select();//下载流量
			$count_traffic = db('radacct')->where(array('username'=>$u))->field('SUM(acctinputoctets + acctoutputoctets)')->select();//已用流量
			$jhtime1 = db('radpostauth')->where("username = '$u' and reply = 'Access-Accept'")->order('authdate asc')->select();//判断最早登陆时间1
			$jhtime2 = db('radacct')->where(array('username'=>$u))->order('acctstarttime asc')->field('acctstarttime')->select();//判断最早登陆时间2
			$max1 = db('radusergroup')->where(['username'=>$u])->field('groupname')->select();//通过账号获取到账号使用的套餐
			$max1_db = $max1[0]['groupname'];
			$max2_days = db('radgroupcheck')->where("groupname = '$max1_db' and attribute = 'Max-Active-Days'")->select();//通过套餐获取天数
			$max2_traffic = db('radgroupcheck')->where("groupname = '$max1_db' and attribute = 'Max-Global-Traffic'")->select();//通过套餐获取流量
			$max_traffic = $max2_traffic ? $max2_traffic[0]['value'] : '1022976';//以获取到总流量
			$max_days = $max2_days ? $max2_days[0]['value'] : '999';//以获取到总天数
			$Surplus_traffic = $max2_traffic ? round($max_traffic*1024,2) - round($count_traffic[0]['SUM(acctinputoctets + acctoutputoctets)']/1024,2) : '1047527424';////开始获取剩余流量
			$count_days = db('radacct')->where("username = '$u' AND AcctSessionTime >= 1 ORDER BY AcctStartTime LIMIT 1")->field('IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400')->select();//已用天数
			//------------------------到期时间
			$Expiry_max_days = $max2_days ? $max2_days[0]['value'] : false;//先判断天数是否正确
			$user_num_activation = db('radacct')->where(array('username'=>$u))->select();//判断用户是否已激活
			if($user_num_activation){
				if($Expiry_max_days){
					if($jhtime1 || $jhtime2){
						//------------剩余天数
						$user_sy_days = $Expiry_max_days - $count_days[0]["IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400"];
						if(0 < $user_sy_days){
						}else{
							//$user_sy_days = $max_days;
						}
						//---------------剩余天数
						$Expirys_time = time()+3600*24*$user_sy_days;
						$Expiry_time = date("Y-m-d H:i:s",$Expirys_time);
					}else{
						$Expiry_time = date("Y-m-d H:i:s",999);
						//$user_sy_days = $max_days;
					}
				}else{
					$Expiry_time = date("Y-m-d H:i:s",999);
					//$user_sy_days = $max_days;
				}
			}else{
				$Expiry_time = '0000-00-00 00:00:00';
				$user_sy_days = $max_days;
			}
			//-------------------到期时间
			
			//流量统一以MB为单位
			
			 $info = array();
			 //已使用流量
			 $info[0] = round($count_traffic[0]['SUM(acctinputoctets + acctoutputoctets)']/1024,2);
			 //总流量
			 $info[1] = round($max_traffic*1024,2);
			 //总天数
			 $info[2] = $max_days;
			 //上传流量
			 $info[3] = round($Upload_traffic[0]['SUM(acctinputoctets)']/1024,2);
			 //下载流量
			 $info[4] = round($Download_traffic[0]['SUM(acctoutputoctets)']/1024,2);
			 //剩余流量
			 $info[5] = round($Surplus_traffic*1024);
			 //到期时间
			 $info[6] = $Expiry_time;
			 //已用天数
			 $info[7] = $count_days[0]["IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400"];
			 //剩余天数
			 $info[8] = $user_sy_days;
			 // $info[9] =
			 // $info[10] =
			 // $info[11] =
			 // $info[12] =
			 // $info[13] =
			 // $info[14] =
			 return $info;
			 
		}else{
			return false;
		}
	}
	
	public function judge(){//判断用户是否过期
		$jy1 = db('radcheck')->where(array("username"=>$this->username,"attribute"=>"Cleartext-Password"))->find();//判断用户是否被禁用
		$jy2 = db('radcheck')->where(array("username"=>$this->username,"attribute"=>"User-Password"))->find();//判断用户是否被禁用
		
		if($this->isuser){//判断用户账号与密码是否正确
			if($jy1 || $jy2){
				$ud = $this->getllts();
				if($ud[8] > 0 && $ud[5] > 0){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
	}
}