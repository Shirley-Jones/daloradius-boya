#!/bin/bash
#Zero Proxy服务启动文件


Start_Service()
{
	Load_profile
	
	
	#启动
	if [ ! -f "$Proxy_Service_File" ]; then
		#失败
		echo "$Proxy_Service_Name Binary file does not exist，Please check if the path is correct ($Proxy_Service_File)";
		exit 1;
		#mkdir /Super
	else
		#启动
		cat $Proxy_Port_Config_File | while read line
		do
			port=`echo $line | cut -d \  -f 2`
			$Proxy_Service_File -l $port -d >/dev/null 2>&1
		done
		Check_Proxy_PID=`ps -ef |grep "$Proxy_Service_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Proxy_PID} ]]; then
			echo "$Proxy_Service_Name Started....."
		else
			echo "$Proxy_Service_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	
	exit 0;
	
}

Stop_Service()
{
	Load_profile
	
	
	
	#停止
	killall -9 $Proxy_Service_Name >/dev/null 2>&1
	sleep 3
	echo "$Proxy_Service_Name Stopped....."
	
	
	exit 0;
	
	
	
	
	
}

Restart_Service()
{
	Load_profile
	
	#启动
	if [ ! -f "$Proxy_Service_File" ]; then
		#失败
		echo "$Proxy_Service_Name Binary file does not exist，Please check if the path is correct ($Proxy_Service_File)";
		exit 1;
		#mkdir /Super
	else
		#停止
		killall -9 $Proxy_Service_Name >/dev/null 2>&1
		sleep 3
		echo "$Proxy_Service_Name Stopped....."
		#启动
		cat $Proxy_Port_Config_File | while read line
		do
			port=`echo $line | cut -d \  -f 2`
			$Proxy_Service_File -l $port -d >/dev/null 2>&1
		done
		Check_Proxy_PID=`ps -ef |grep "$Proxy_Service_Name" |grep -v "grep" |awk '{print $2}'`
		if [[ ! -z ${Check_Proxy_PID} ]]; then
			echo "$Proxy_Service_Name Started....."
		else
			echo "$Proxy_Service_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	exit 0;
	
}


Check_Service()
{
	
	Load_profile
	
	printf "%-70s"  "$Proxy_Service_Name PID"
	Check_Proxy_PID=$(echo `ps -ef |grep "$Proxy_Service_Name" |grep -v "grep" |awk '{print $2}'` | tr -d '\n') 
	if [[ ! -z ${Check_Proxy_PID} ]]; then
		echo -e "[ \033[32m Running \033[0m ]"
	else
		echo -e "[ \033[31m Not running \033[0m ]"
	fi
	
	exit 0;
	
}

Load_profile()
{
	Proxy_Port_Config_File="/Shirley/Config/Port_List.conf";
	Proxy_Service_File="/Shirley/Core/Proxy.bin";
	Proxy_Service_Name="Proxy.bin";
	
	
}



case $1 in
	"start")
		Start_Service
	;;
	"restart")
		Restart_Service
	;;
	"stop")
		Stop_Service
	;;	
	"status")
		Check_Service
	;;
	"state")
		Check_Service
	;;
	
	*) 
		echo "Please execute the following command $0 [start|restart|stop|status|state] For example, restart proxy service command $0 restart";
		exit 0;
    ;;
esac 


