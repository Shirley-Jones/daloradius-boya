<?php
 
	include_once(dirname(__FILE__).'/../library/config_read.php');
	
	switch($configValues['CONFIG_LANG']) {
		
		case "zh_CN":
			include (dirname(__FILE__)."/zh_CN.php");
			break;
		case "en":
			include (dirname(__FILE__)."/en.php");
			break;
		case "ru":
			include (dirname(__FILE__)."/ru.php");
			break;
		case "hu":
			include (dirname(__FILE__)."/hu.php");
			break;
		case "it":
			include (dirname(__FILE__)."/it.php");
			break;
		case "es_VE":
			include (dirname(__FILE__)."/es_VE.php");
			break;
		/*
		 * file is currently broken and needs a fix...
		case "ro":
			include (dirname(__FILE__)."/ro.php");
			break;
		*/
		case "pt_br":
			include (dirname(__FILE__)."/pt_br.php");
			break;
		default:
			include (dirname(__FILE__)."/zh_CN.php");
			break;
	}

?>
