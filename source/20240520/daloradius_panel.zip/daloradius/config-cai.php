
                                <ul id="subnav">

					<li><a href="info.php">公告</a></li>
					<li><a href="tz.php">服务器信息</a></li>
                                </ul>

                </div>
	
