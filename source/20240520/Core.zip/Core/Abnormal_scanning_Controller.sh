#!/bin/bash
#服务启动文件


Start_Service()
{
	Load_profile
	
	
	#启动
	if [ ! -f "$Service_File" ]; then
		#失败
		echo "$Service_Name Binary file does not exist，Please check if the path is correct ($Service_File)";
		exit 1;
		#mkdir /Super
	else
		#启动
		eval nohup ${Service_File} 2>&1 &
		Check_Service_PID=`ps -ef |grep "$Service_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Service_PID} ]]; then
			echo "$Service_Name Started....."
		else
			echo "$Service_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	
	exit 0;
	
}

Stop_Service()
{
	Load_profile
	
	
	#停止
	killall -9 $Service_Name >/dev/null 2>&1
	echo "$Service_Name Stopped....."
	
	
	
}

Restart_Service()
{
	Load_profile
	
	#启动
	if [ ! -f "$Service_File" ]; then
		#失败
		echo "$Service_Name Binary file does not exist，Please check if the path is correct ($Service_File)";
		exit 1;
		#mkdir /Super
	else
		#停止
		killall -9 $Service_Name >/dev/null 2>&1
		echo "$Service_Name Stopped....."
		#启动
		eval nohup ${Service_File} 2>&1 &
		Check_Service_PID=`ps -ef |grep "$Service_Name" |grep -v "grep" |awk '{print $2}'`;
		if [[ ! -z ${Check_Service_PID} ]]; then
			echo "$Service_Name Started....."
		else
			echo "$Service_Name Fail to start.....";
			exit 1;
		fi
	fi
	
	
	exit 0;
	
}


Check_Service_Run()
{
	
	Load_profile
	
	printf "%-70s"  "$Service_Name PID"
	Check_Service_PID=$(echo `ps -ef |grep "$Service_Name" |grep -v "grep" |awk '{print $2}'` | tr -d '\n') 
	if [[ ! -z ${Check_Service_PID} ]]; then
		echo -e "[ \033[32m Running \033[0m ]"
		exit 0;
	else
		echo -e "[ \033[31m Not running \033[0m ]"
		exit 1;
	fi
	
	
	
	
	
	
}

Load_profile()
{


	Service_File="/Shirley/Core/Abnormal_scanning.sh";
	Service_Name="Abnormal_scanning.sh";
	
	
}



case $1 in
	"start")
		Start_Service
	;;
	"restart")
		Restart_Service
	;;
	"stop")
		Stop_Service
	;;	
	"status")
		Check_Service_Run
	;;
	"state")
		Check_Service_Run
	;;
	
	*) 
		echo "Please execute the following command $0 [start|restart|stop|status|state] For example, restart proxy service command $0 restart";
		exit 0;
    ;;
esac 


