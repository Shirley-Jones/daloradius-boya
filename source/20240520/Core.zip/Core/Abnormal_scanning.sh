#!/bin/sh

source /Shirley/Config/auth_config.conf

for((;;))
do
        mysql -h${MySQL_Host} -P${MySQL_Port} -u${MySQL_User} -p${MySQL_Pass} -e "use ${MySQL_DB}; UPDATE radacct SET acctstoptime = NOW() WHERE acctstoptime IS NULL AND TIMESTAMPDIFF(SECOND, acctstarttime, NOW()) - acctsessiontime >= 180";
        sleep ${Abnormal_scanning_interval}
done
