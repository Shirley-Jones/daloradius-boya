#!/bin/sh

source /Shirley/Config/MySQL.conf

for((;;))
do
        mysql -h${MySQL_Host} -P${MySQL_Port} -u${MySQL_User} -p${MySQL_Pass} -e "use ${RADIUS_DB}; UPDATE radacct SET acctstoptime = NOW() WHERE acctstoptime IS NULL AND TIMESTAMPDIFF(SECOND, acctstarttime, NOW()) - acctsessiontime >= 180";
        sleep ${Scan_interval}
done
