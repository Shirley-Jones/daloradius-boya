<?php
/**
 * Author: DongGua
 * E-mail zhendongdong@foxmail.con
 * Date: 2018/6/18
 * Time: 18:21
 */
require('../system.php');
$action = $_GET['action'];
$agent = $_GET['agent'] ?: 0;
$username = $_GET['username'];
$password = $_GET['password'];



define("DID", $agent);

function create_order()
{
    return rand(1111, 999) . time();
}

function check_user()
{
    $username = $_GET['username'] ?: $_SESSION["app"]['username'];
    $password = $_GET['password'] ?: $_SESSION["app"]['password'];
	if(trim($username) == "" || trim($password) == ""){
		die("账号密码不能为空！");
	}else{
		$user_login = db('radcheck')->where(array("username"=>$username,"value"=>$password))->find();
		if($user_login){
			//登录成功！
			$_SESSION["app"]["username"] = $username;
			$_SESSION["app"]["password"] = $password;
		}else{
			die("登录失败，账号或密码错误！");
		}
	}
	
    return $res;
}

function getClientIP()
{
    global $ip;
    if (getenv("HTTP_CLIENT_IP"))
        $ip = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR"))
        $ip = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR"))
        $ip = getenv("REMOTE_ADDR");
    else $ip = "Unknow";
    return $ip;
}


switch ($action) {
    case 'shop':
        $user_info = check_user();
        $title = '充值与续费';
        include("api_head.php");
        include("mode/ad.php");
        include("api_footer.php");
        break; 
	case 'line':
        $user_info = check_user();
        $title = '线路安装';
        include("api_head.php");
        include("mode/line.php");
        include("api_footer.php");
        break;
    case 'help':
//        $user_info = check_user();
        $title = '帮助中心';
        include("api_head.php");
        include("mode/help.php");
        include("api_footer.php");
        break;
    case 'connect':
//        $user_info = check_user();
        $title = '客服中心';
        include("api_head.php");
        include("mode/connect.php");
        include("api_footer.php");
        break;
    case 'notice_list':
        include('api_head.php');
        //include('list_gg.php');
        $u = $_GET['username'];
        $p = $_GET['password'];
        $db = db('app_gg');
        $list = $db->where(["daili" => DID])->order('id DESC')->select();
        echo '<div style="margin:10px 10px;">';
        echo '<div class="alert alert-warning">您可以在这看到最近30条消息通知</div>';
        echo '</div>';
        if ($list) {
            echo '<ul class="list-group">';
            foreach ($list as $v) {
                echo '<li class="list-group-item"><a href="">' . $v['name'] . '</a></li>
				';
            }
            echo '</ul>';
        } else {
            echo '消息已经删除或者不存在！';
        }

        include("api_footer.php");
        break;
    case 'notice':
        $db = db('app_gg');
        if ($notice = $db->where(["daili" => DID])->order('id DESC')->find()) {
            die(json_encode([
                'status' => 'success',
                'title' => $notice['name'],
                'content' => $notice['content']
            ]));
        };

        break;
    case 'userinfo':
		$ud = new test($username,$password,true);
		$uinfo = $ud->getllts();
		
		if(!$ud->judge()){
			die(json_encode(['status' => 'error']));
		}else{
			$ll_bytes = round($uinfo[5],0);
			$ll_KB = round($uinfo[5]/1024,0);
			$ll_MB = round($uinfo[5]/1024/1024,0);
			$ll_GB = round($uinfo[5]/1024/1024/1024,0);
			
			if($ll_GB>"1"){
				//是
				$_All = 'NO_LIMIT';
			}else{
				//不是
				$_All = $ll_bytes;
			}
			die(json_encode([
                'status' => 'success', 
                'bl' => $_All,   //流量单位B  最大1.5-1.9G的样子   NO_LIMIT 为不限流量
                'sy' => $uinfo[8]
            ]));
		}
        break;
    case 'reg':
        $title = '新用户注册';
        include("api_head.php");
        $m =  new Map();
        $type = $m->type("cfg_app")->getValue("reg_type");
        if($type == "sms"){
            include("mode/dx_reg.php");
        }else{
            include("mode/app_reg.php");
        }
        include("api_footer.php");
    break;
		
		
break;
}