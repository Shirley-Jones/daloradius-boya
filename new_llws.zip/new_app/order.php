<?php
$title = '充值完成';
include("api_head.php");
$order_no = $_POST["out_trade_no"]; //订单号
?>
    <div style="margin: 10px">
        <h3>支付完成</h3>
        <div style="background: #ffffff;padding: 10px;margin-top: 10px;border-top:3px solid #328cc9">
            <b>您已经成功购买了所选套餐啦！回到APP查看吧！</b>
            <br>
            (您可能需要重新连接才能更新您的用户信息哦~ 如有任何疑问欢迎咨询客服)
        </div>
    </div>
<?php
include("api_footer.php");
?>