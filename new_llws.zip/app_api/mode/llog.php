<div style="background:#efefef;"><?php
//require("../../system.php");
	$u = $_GET['username'];
	$p = $_GET['password'];
		$list = db('radacct')->where(array('username'=>$u))->order('acctstarttime DESC')->select();
		echo ' 	<div class="alert alert-success">可以查看近期每天的流量使用情况。每次断开后数据才会更新到此处哦！最多查看30天！</div>
		<style>.topline{
			border-bottom:1px solid #ccc;height:120px;;background-repeat:no-repeat;color:#333;
			background:#fff;
			margin-bottom:10px;
			}
		.topline h3{color:#222}
		.topn{font-size:30px;color:#222;float:left;line-height:120px;margin-left:15px;width:120px;}
		.topc{
			float:left;
			margin-top:10px;
			text-align:left;
		}
		</style>';
  $i = 1;
		foreach($list as $vo){	
			$l = printmb($vo['acctinputoctets'] + $vo['acctoutputoctets']);
			$t = explode("-",$vo['acctstarttime']);
			//substr($t[2],0,1);
			if($vo['acctinputoctets'] + $vo['acctoutputoctets'] !== 0){
	  echo '<div class="topline"><div class="topn">'.$t[1].'月'.substr($t[2],0,1).'日</div><div class="topc"><h3>'.round($l['n'],2).$l['p'].'</h3><div class="topu">开始时间：'.$vo['acctstarttime'].'<br/>结束时间：'.$vo['acctstoptime'].'</div></div></div>';
			}
	$i++;
		}
		
?>
<div style="text-align:center;padding:15px;">
没有更多数据喽~~
</div>
</div>