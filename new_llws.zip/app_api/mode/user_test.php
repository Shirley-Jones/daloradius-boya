<?php
$usernames_tests = db('radcheck')->where(array("op"=>":="))->select();
//var_dump($usernames_tests);
for ($i = 1; $usernames_tests[$i]; $i++) {
    $u =$usernames_tests[$i]['username'];
	// $u = 888;
    $user_date_time = date("Y-m-d",strtotime("-3 day",time())).' 00:00:00';
    $user_date = db('radacct')->where("username = '{$u}' and acctstarttime >= '{$user_date_time}'")->field('SUM(acctinputoctets + acctoutputoctets)')->select();
    if($user_date !== null){
        // /*判断流量排行是否存在这个客户*/
        $user_test = db('top')->where(array("username"=>$u))->find();
		if($user_date[0]["SUM(acctinputoctets + acctoutputoctets)"] === null){
			$user_date[0]["SUM(acctinputoctets + acctoutputoctets)"] = 0;
		}
        if($user_test){
            /*存在账号,修改数据*/
            db('top')->where(array('username'=>$u))->update(array(
                'username'=>$u,
                'data'=>$user_date[0]["SUM(acctinputoctets + acctoutputoctets)"],
                'time'=>date("Y-m-d",time())
            ));
        }else{
            /*不存在这个账号,插入数据*/
            db('top')->insert(array(
                'username'=>$u,
                'data'=>$user_date[0]["SUM(acctinputoctets + acctoutputoctets)"],
                'time'=>date("Y-m-d",time())
            ));
        }
    }
    //echo $i.'   ';
	// var_dump($u);
	// echo "<br>";
	// var_dump($user_date_time);
	// echo "<br>";
	// var_dump($user_date);
	// echo "<br>";
	// var_dump($user_date[0]["SUM(acctinputoctets + acctoutputoctets)"]);
	// echo "<br>";
	// var_dump(date("Y-m-d",time()));
	// echo "<br>";
	// var_dump($user_test);
	// break;
}
echo '已经运行了'.$i.'次';
?>