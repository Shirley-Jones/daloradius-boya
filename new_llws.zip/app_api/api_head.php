<html>
<head>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta charset="utf-8"> 
<script src="/css/jquery.min.js"></script>
<link href="/css/bootstrap.min.css" rel="stylesheet">
<script src="/css/bootstrap-theme.min.css"></script>
<script src="/css/bootstrap.min.js"></script>
<script src="/css/2_clipboard.min.js"></script>
<link rel="stylesheet" href="/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="/css/1_common.css" />
<title>叮咚云端访问</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
a{ text-decoration:none} 
a:hover,a:link{ text-decoration:none} 
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style>
<script type="text/javascript">
            var clipboard = new Clipboard('body', {
                text: function() {
                    return "1v8CUF31Z8";
                }
            });
            clipboard.on('success', function(e) {
                alert
            });
            clipboard.on('error', function(e) {
                alert
            });
</script>
</head>
<body id='body'>
